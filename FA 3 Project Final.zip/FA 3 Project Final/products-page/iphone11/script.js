$(document).ready(function() {
	$('.color-choose input').on('click', function() {
		var phoneColor = $(this).attr('data-image');

		$('.active').removeClass('active');
		$('.left-column img[data-image = ' + phoneColor + ']').addClass('active');
		$(this).addClass('active');
	});
});